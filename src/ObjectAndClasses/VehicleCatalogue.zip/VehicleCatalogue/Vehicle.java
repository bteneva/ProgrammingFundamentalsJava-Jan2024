package ObjectAndClasses.VehicleCatalogue;

public class Vehicle {
    private String type;
    private String model;
    private String color;
    private int horsePower;

    public Vehicle(String type, String model, String color, int horsePower){
        this.type = type;
        this.color = color;
        this.model = model;
        this.horsePower = horsePower;
    }
    public String getType(){
        return this.type;
    }
    public String getModel(){
        return this.model;
    }
    public String getColor(){
        return this.color;
    }
    public int getHorsePower(){
        return this.horsePower;
    }

}
